namespace Google_DocumentsList
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.documentsView = new System.Windows.Forms.TreeView();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // documentsView
            // 
            this.documentsView.ImageIndex = 0;
            this.documentsView.ImageList = this.imageList;
            this.documentsView.Location = new System.Drawing.Point(12, 24);
            this.documentsView.Name = "documentsView";
            this.documentsView.SelectedImageIndex = 0;
            this.documentsView.Size = new System.Drawing.Size(431, 400);
            this.documentsView.TabIndex = 1;
            this.documentsView.AfterCollapse += new System.Windows.Forms.TreeViewEventHandler(this.documentsView_AfterCollapse);
            this.documentsView.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.documentsView_AfterExpand);
            // 
            // imageList
            // 
            this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList.Images.SetKeyName(0, "CLSDFOLD.BMP");
            this.imageList.Images.SetKeyName(1, "OPENFOLD.BMP");
            this.imageList.Images.SetKeyName(2, "DOC.BMP");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 450);
            this.Controls.Add(this.documentsView);
            this.Name = "Form1";
            this.Text = "Not logged in yet";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView documentsView;
        private System.Windows.Forms.ImageList imageList;
    }
}

