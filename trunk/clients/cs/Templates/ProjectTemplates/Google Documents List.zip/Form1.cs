using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#region Google Calendar specific imports
using Google.GData.Client;
using Google.GData.Extensions;
using Google.GData.Documents;
using Google.GData.Tools;
#endregion

namespace Google_Calendar1
{
    public partial class Form1 : Form
    {

        private String googleAuthToken = null;
        private DocumentsService documentsService = null;

        public Form1()
        {
            InitializeComponent();

            this.documentsService = new DocumentsService("GoogleDocumentsSample");

            if (this.googleAuthToken == null)
            {
                GoogleClientLogin loginDialog = new GoogleClientLogin(this.documentsService, "youremailhere@gmail.com");
                loginDialog.ShowDialog();

                this.googleAuthToken = loginDialog.AuthenticationToken;

                if (this.googleAuthToken != null)
                {
                    this.documentsService.SetAuthenticationToken(this.googleAuthToken);
                    this.Text = "Successfully logged in";
                } 
            }
        }
    }
}