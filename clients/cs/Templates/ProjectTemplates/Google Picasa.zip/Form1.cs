using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#region Google Calendar specific imports
using Google.GData.Client;
using Google.GData.Extensions;
using Google.GData.Photos;
using Google.GData.Tools;
#endregion

namespace Google_Calendar1
{
    public partial class Form1 : Form
    {

        private String googleAuthToken = null;
        private PicasaService picasaService = null;

        public Form1()
        {
            InitializeComponent();

            this.picasaService = new PicasaService("GoogleSpreadsheetsSample");

            if (this.googleAuthToken == null)
            {
                GoogleClientLogin loginDialog = new GoogleClientLogin(this.picasaService, "youremailhere@gmail.com");
                loginDialog.ShowDialog();

                this.googleAuthToken = loginDialog.AuthenticationToken;

                if (this.googleAuthToken != null)
                {
                    this.picasaService.SetAuthenticationToken(this.googleAuthToken);
                    this.Text = "Successfully logged in";
                }
            }
        }
    }
}