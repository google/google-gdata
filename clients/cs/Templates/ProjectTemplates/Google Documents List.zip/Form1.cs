using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#region Google_Documents_List5 specific imports
using Google.GData.Client;
using Google.GData.Extensions;
using Google.GData.Documents;
using Google.GData.Tools;
#endregion

namespace Google_DocumentsList
{
    public partial class Form1 : Form
    {

        private String googleAuthToken = null;
        private DocumentsService documentsService = null;

        public Form1()
        {
            InitializeComponent();

            this.documentsService = new DocumentsService("GoogleDocumentsSample");

            if (this.googleAuthToken == null)
            {
                GoogleClientLogin loginDialog = new GoogleClientLogin(this.documentsService, "youremailhere@gmail.com");
                if (loginDialog.ShowDialog() == DialogResult.OK)
                {
                    this.googleAuthToken = loginDialog.AuthenticationToken;
                    if (this.googleAuthToken != null)
                    {
                        this.documentsService.SetAuthenticationToken(this.googleAuthToken);
                        this.Text = "Successfully logged in";

                        DocumentsListQuery query = new DocumentsListQuery();
                        DocumentsFeed feed = this.documentsService.Query(query);
                        this.listView.Clear();

                        if (feed != null && feed.Entries.Count > 0)
                        {
                            foreach (DocumentEntry entry in feed.Entries)
                            {
                                ListViewItem item = new ListViewItem(entry.Title.Text);
                                item.Tag = entry;
                                this.listView.Items.Add(item);
                            }
                        }
                        this.listView.Update();
                    }
                }
            }
        }
    }
}